#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    char str[100]; 
    int i, count = 0;

    printf("Enter a string: ");
    fgets(str, 100, stdin);

    str[strcspn(str, "\n")] = '\0';

   
    for (i = 0; str[i] != '\0'; i++) {
        if (isalpha(str[i])) {
            count++;
        }
    }   
    
    printf("Number of letters: %d\n", count);

    if (access("mypipe", F_OK) == -1) {
        mkfifo("mypipe", 0666);
    }

    int fd = open("mypipe", O_WRONLY);
    if (fd == -1) {
        perror("Error opening pipe for writing");
        return 1;
    }

    write(fd, &count, sizeof(count));
    
    close(fd);

   
    getchar(); 

    return 0;
}

