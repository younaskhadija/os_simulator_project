#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("Playing a sound...\n");

   
    int result = system("aplay song.wav");
    if (result != 0) {
        printf("Error: Could not play sound. Make sure 'aplay' is installed and 'song.wav' exists.\n");
    }

 
    if (argc > 1) {
        int x = atoi(argv[1]);
        mkfifo("mypipe", 0666);
        int fd = open("mypipe", O_WRONLY);
        write(fd, &x, sizeof(x));
        close(fd);
    }

   
    printf("Press Enter to exit...\n");
    getchar();

    return 0;
}

